﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace Arogya
{
    public partial class Admin : System.Web.UI.Page
    {
        OleDbConnection myconn = new OleDbConnection("provider=msdaora; data source =orcl1 ; user id=scott;password=redacid;unicode=true;");
        OleDbConnection cc = new OleDbConnection("provider=msdaora; data source =orcl1 ; user id=scott;password=redacid;unicode=true;");
        
         protected void Page_Load(object sender, EventArgs e)
        {
           
            //myconn.Open();
            string sql = "select empno from emp";
            //OleDbDataAdapter adp = new OleDbDataAdapter(sql, cc);
            //DataTable dt = new DataTable();
            //adp.Fill(dt);
            //GridView1.DataSource = dt;
            //GridView1.DataBind();
            
            try
            {
                if (Session["admin"].ToString() != "Admin")
                {
                    Response.Redirect("Default.aspx");
                }
            }
            catch (Exception ep)
            {
                Response.Redirect("Default.aspx");
            }

        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}