﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace Arogya
{
    
    public partial class WebForm3 : System.Web.UI.Page
    {
        public string err;
        public string postedValues;
        protected void Page_Load(object sender, EventArgs e)
        {
          //  postedValues = Request.Form["pg"];
          // if(postedValues=="admin")
           // Response.Redirect("Admin.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // OleDbConnection cc = new OleDbConnection("provider=msdaora;data source=orcl1;user id=scott;password=redacid;unicode=true;");
             //string sql = "select * from admin where uid= " + TextBox1.Text + " and pwd =" + TextBox2.Text;
             //OleDbDataAdapter adpn = new OleDbDataAdapter(sql, cc);
             //DataTable dtn = new DataTable();
             //adpn.Fill(dtn);
            if (TextBox1.Text == "Admin" && TextBox2.Text == "pwd")
            {
                Session["admin"] = "Admin";
                Response.Redirect("Admin.aspx");
            }
            else
            {
                err = "INCORECT USER NAME OR PASSWORD";
            }

        }

    }
}